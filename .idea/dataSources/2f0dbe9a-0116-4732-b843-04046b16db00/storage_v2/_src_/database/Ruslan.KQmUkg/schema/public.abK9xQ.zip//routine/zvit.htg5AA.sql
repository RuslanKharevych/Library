CREATE FUNCTION zvit()
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
name text;
amounter FLOAT;
all_text text; 
kursor CURSOR FOR select name_t,(0.3*sum(case when extract(year from date) = extract(year from current_date) then
                       (CASE WHEN postachalniki.nacinka=true then kilkist*1.1*price ELSE kilkist*price end) else 0 end)) as amount
from zbut,tovaru,postachalniki where postachalniki.id_p=zbut.id_p and tovaru.id_t=zbut.id_t group by name_t;
BEGIN
all_text:='                                          Звіт'||E'\n';
all_text:=all_text ||'               про сумарний прибуток фірми 
          за кожний товар у поточному році. '||E'\n';
all_text:=all_text ||'станом на: '||current_date||E'\n\n';
all_text:=all_text||'Товар'||repeat(' ',43)||'Прибуток'||E'\n';
all_text:=all_text ||'---------------------------------------------------------------------------------------'||E'\n';
open kursor;
LOOP
FETCH kursor INTO name,amounter;
exit when not found;
all_text := all_text||rpad(name,25,'`')||rpad(CAST(amounter as VARCHAR(15)),25,'`')||E'\n'||E'\n';
END LOOP;
CLOSE kursor;
RETURN all_text;
END;
$$;

